#include <iostream>
#include <string>
using namespace std;

// =====================================================
// =============== APPLICANT STRUCTURE =================
// =====================================================
struct Applicant {
    int applicant_id;
    float height;
    float weight;
    float eyesight;
    string status;

    Applicant* next;
    Applicant* prev;
};

// =====================================================
// =============== DOUBLY LINKED LIST QUEUE ============
// =====================================================
class ApplicantQueue {
private:
    Applicant* front;
    Applicant* rear;

public:
    ApplicantQueue() {
        front = rear = nullptr;
    }

    // Add new applicant at end (enqueue)
    void enqueue(int id, float h, float w, float e, string s) {
        Applicant* newNode = new Applicant{id, h, w, e, s, nullptr, nullptr};

        if (rear == nullptr) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            newNode->prev = rear;
            rear = newNode;
        }
        cout << "Applicant " << id << " added at end of queue.\n";
    }

    // Remove applicant from front (dequeue)
    void dequeue() {
        if (front == nullptr) {
            cout << "Queue is empty!\n";
            return;
        }

        Applicant* temp = front;
        front = front->next;

        if (front)
            front->prev = nullptr;
        else
            rear = nullptr;

        cout << "Applicant " << temp->applicant_id << " has completed test and left the line.\n";
        delete temp;
    }

    // Remove applicant from 2nd position (urgency case)
    void removeSecond() {
        if (front == nullptr || front->next == nullptr) {
            cout << "Not enough applicants to remove 2nd person!\n";
            return;
        }

        Applicant* second = front->next;
        Applicant* third = second->next;

        front->next = third;
        if (third)
            third->prev = front;
        else
            rear = front;

        cout << "Applicant " << second->applicant_id << " (2nd position) left due to urgency.\n";
        delete second;
    }

    // Display current queue
    void display() {
        if (front == nullptr) {
            cout << "No applicants in line.\n";
            return;
        }

        cout << "\nCurrent Applicants in Line:\n";
        Applicant* temp = front;
        while (temp != nullptr) {
            cout << "ID: " << temp->applicant_id
                 << " | Height: " << temp->height
                 << " | Weight: " << temp->weight
                 << " | Eyesight: " << temp->eyesight
                 << " | Status: " << temp->status << endl;
            temp = temp->next;
        }
    }
};

// =====================================================
// ====================== MAIN =========================
// =====================================================
int main() {
    ApplicantQueue q;

    // Add 7 applicants
    q.enqueue(1, 5.6, 60, 6.0, "Waiting");
    q.enqueue(2, 5.8, 65, 6.2, "Waiting");
    q.enqueue(3, 5.7, 70, 6.0, "Waiting");
    q.enqueue(4, 6.0, 75, 6.5, "Waiting");
    q.enqueue(5, 5.5, 68, 6.1, "Waiting");
    q.enqueue(6, 5.9, 72, 6.3, "Waiting");
    q.enqueue(7, 6.1, 80, 6.4, "Waiting");

    q.display();

    // 2nd person has urgency
    cout << "\n--- Urgency Event ---\n";
    q.removeSecond();
    q.display();

    // 1st applicant gives test and leaves
    cout << "\n--- First Applicant Gives Test ---\n";
    q.dequeue();
    q.display();

    return 0;
}
