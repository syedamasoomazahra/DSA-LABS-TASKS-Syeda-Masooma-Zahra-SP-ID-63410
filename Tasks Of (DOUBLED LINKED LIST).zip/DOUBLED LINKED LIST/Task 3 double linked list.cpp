#include <iostream>
using namespace std;

struct Player {
    string name;
    int score;
    Player* prev;
    Player* next;
};

// Insert in sorted order
void addPlayer(Player*& head, string name, int score) {
    Player* newNode=new Player();
    newNode->name=name;
    newNode->score=score;
    newNode->prev=newNode->next=NULL;

    // Case 1: Empty list
    if (head==NULL) {
        head=newNode;
        return;
    }

    Player* temp=head;

    // Case 2: Insert at beginning
    if (score < head->score) {
        newNode->next=head;
        head->prev=newNode;
        head=newNode;
        return;
    }

    // Case 3: Insert in middle or end
    while (temp->next !=NULL && temp->next->score<=score) {
        temp=temp->next;
    }

    newNode->next=temp->next;
    newNode->prev=temp;

    if (temp->next!=NULL)
        temp->next->prev=newNode;

    temp->next=newNode;
}

// Delete a player by name
void deletePlayer(Player*& head,string name) {
    if (head==NULL) {
        cout<<"List is empty!\n";
        return;
    }

    Player* temp=head;

    // Search by name
    while (temp !=NULL && temp->name !=name) {
        temp=temp->next;
    }

    if (temp==NULL) {
        cout<<"Player " <<name<<" not found!\n";
        return;
    }

    if (temp->prev !=NULL)
        temp->prev->next=temp->next;
    else
        head=temp->next;  // deleting head

    if (temp->next !=NULL)
        temp->next->prev=temp->prev;

    cout<<"Deleted Player: "<<temp->name<<" (Score: "<<temp->score<< ")\n";
    delete temp;
}

// Display whole list (ascending)
void displayList(Player* head) {
    if (head==NULL) {
        cout<<"List is empty!\n";
        return;
    }

    cout<<"\nAll Players (Ascending Scores):\n";
    Player* temp=head;
    while (temp !=NULL) {
        cout<<temp->name<<" - "<<temp->score<<endl;
        temp=temp->next;
    }
}

// Display lowest score player
void displayLowest(Player* head) {
    if (head==NULL) {
        cout<<"List is empty!\n";
        return;
    }
    cout<<"Lowest Score: "<<head->name<<" - "<<head->score<<endl;
}

// Display all players with same score
void displayByScore(Player* head, int score) {
    if (head==NULL) {
        cout<<"List is empty!\n";
        return;
    }
    bool found=false;
    cout<<"Players with score "<<score<<":\n";
    while (head !=NULL) {
        if (head->score==score) {
            cout<<head->name<<endl;
            found=true;
        }
        head=head->next;
    }
    if (!found)
        cout<<"No player has score "<<score<<endl;
}

// Display backward from a given player
void displayBackward(Player* head, string name) {
    Player* temp=head;

    // Find the player
    while (temp !=NULL && temp->name !=name) {
        temp=temp->next;
    }

    if (temp==NULL) {
        cout<<"Player "<<name<<" not found!\n";
        return;
    }

    cout<<"Backward from "<<name<< ":\n";
    while (temp !=NULL) {
        cout<<temp->name<< " - " <<temp->score<< endl;
        temp=temp->prev;
    }
}

// ================= MAIN ==================
int main() {
    Player* head=NULL;
    int choice, score;
    string name;

    do {
        cout<<"\n===== Golf Tournament Menu =====\n";
        cout<<"1. Add Player\n";
        cout<<"2. Delete Player\n";
        cout<<"3. Display All Players\n";
        cout<<"4. Display Lowest Score\n";
        cout<<"5. Display Players with Same Score\n";
        cout<<"6. Display Backward from a Player\n";
        cout<<"7. Exit\n";
        cout<<"Enter choice: ";
        cin>>choice;

        switch (choice) {
            case 1:
                cout<<"Enter player name: ";
                cin>>name;
                cout<<"Enter player score: ";
                cin>>score;
                addPlayer(head, name, score);
                break;

            case 2:
                cout<<"Enter name of player to delete: ";
                cin>>name;
                deletePlayer(head, name);
                break;

            case 3:
                displayList(head);
                break;

            case 4:
                displayLowest(head);
                break;

            case 5:
                cout<<"Enter score to search: ";
                cin>>score;
                displayByScore(head, score);
                break;

            case 6:
                cout<<"Enter player name to start backward display: ";
                cin>>name;
                displayBackward(head, name);
                break;

            case 7:
                cout<<"Exiting program...\n";
                break;

            default:
                cout<<"Invalid choice!\n";
        }
    } while(choice !=7);

    return 0;
}