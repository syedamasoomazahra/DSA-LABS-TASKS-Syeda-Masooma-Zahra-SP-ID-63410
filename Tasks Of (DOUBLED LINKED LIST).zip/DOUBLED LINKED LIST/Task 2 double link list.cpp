#include <iostream>
using namespace std;

// Node structure for doubly linked list
struct Node {
    int data;       
    Node* prev;
    Node* next;
};

// Function to insert node at end
void insertAtEnd(Node*& head, int value) {
    Node* newNode=new Node();
    newNode->data=value;
    newNode->next=NULL;

    if (head==NULL) {
        newNode->prev=NULL;
        head=newNode;
    } else {
        Node* temp =head;
        while (temp->next !=NULL) {
            temp=temp->next;
        }
        temp->next=newNode;
        newNode->prev=temp;
    }
}

// Display the linked list (for checking)
void display(Node* head) {
    Node* temp=head;
    int day=1;
    cout<<"Rainfall Data (Day-wise):\n";
    while (temp !=NULL) {
        cout<<"Day "<<day<< ": "<<temp->data<<" mm\n";
        temp=temp->next;
        day++;
    }
    cout<<endl;
}

int main() {
    Node* head = NULL;
    int rainfall;

    // Input rainfall for 7 days
    for (int i=1; i<=7; i++) {
        do {
            cout<<"Enter rainfall for Day "<<i<<" (mm): ";
            cin>>rainfall;
            if (rainfall < 0) {
                cout<<"Invalid! Rainfall cannot be negative.\n";
            }
        } while (rainfall<0);

        insertAtEnd(head,rainfall);
    }

    display(head);

    // Calculate total and average
    Node* temp=head;
    int total=0, count=0;
    int maxRain=-1, minRain=999999, maxDay=0, minDay=0;
    int day=1;

    while (temp !=NULL) {
        total +=temp->data;
        count++;

        if (temp->data>maxRain) {
            maxRain=temp->data;
            maxDay=day;
        }
        if (temp->data<minRain) {
            minRain=temp->data;
            minDay=day;
        }

        temp=temp->next;
        day++;
    }

    double average = (count > 0) ? (double)total / count : 0;

    cout<< "Total rainfall of the week: "<<total<<" mm\n";
    cout<< "Average rainfall of the week: "<<average<<" mm\n";
    cout<< "Highest rainfall: " <<maxRain<<" mm on Day "<<maxDay<<endl;
    cout<< "Lowest rainfall: " <<minRain<<" mm on Day "<<minDay<<endl;

    // Rainfall of day after 5th node
    temp=head;
    int nodeCount=1;
    while (temp !=NULL && nodeCount<6) {
        temp=temp->next;
        nodeCount++;
    }

    if (temp !=NULL) {
        cout<<"Rainfall of Day after 5th node (Day 6): "<<temp->data<<" mm\n";
    } else {
        cout<<"No 6th day exists in the list.\n";
    }

    return 0;
}