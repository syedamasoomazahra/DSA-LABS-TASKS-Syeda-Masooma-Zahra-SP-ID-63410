#include <iostream>
using namespace std;

// Node structure
struct Node {
    int data;
    Node* prev;
    Node* next;
};

// Head pointer
Node* head = NULL;

// Function to create a new node
Node* createNode(int value) {
    Node* newNode=new Node;
    newNode->data=value;
    newNode->prev=NULL;
    newNode->next=NULL;
    return newNode;
}

// Insert at beginning
void insertAtBeginning(int value) {
    Node* newNode=createNode(value);
    if (head==NULL) {
        head=newNode;
        return;
    }
    newNode->next=head;
    head->prev=newNode;
    head=newNode;
}

// Insert after a specific value
void insertAfterValue(int value, int newValue) {
    Node* temp=head;
    while(temp!=NULL && temp->data!=value) {
        temp=temp->next;
    }
    if (temp==NULL) {
        cout<<"Value "<<value<<" not found!\n";
        return;
    }
    Node* newNode=createNode(newValue);
    newNode->next=temp->next;
    newNode->prev=temp;
    if (temp->next!=NULL) {
        temp->next->prev=newNode;
    }
    temp->next=newNode;
}

// Delete at beginning
void deleteAtBeginning() {
    if (head==NULL) {
        cout<<"List is empty!\n";
        return;
    }
    Node* temp=head;
    head=head->next;
    if (head!=NULL) {
        head->prev=NULL;
    }
    delete temp;
}

// Delete after a specific value
void deleteAfterValue(int value) {
    Node* temp=head;
    while (temp!=NULL && temp->data!=value) {
        temp=temp->next;
    }
    if (temp==NULL || temp->next==NULL) {
        cout<<"No node found after "<<value<<"\n";
        return;
    }
    Node* delNode=temp->next;
    temp->next=delNode->next;
    if (delNode->next!=NULL) {
        delNode->next->prev=temp;
    }
    delete delNode;
}

// Display list
void displayList() {
    Node* temp=head;
    cout<<"Doubly Linked List: ";
    while (temp!=NULL) {
        cout<<temp->data << " <-> ";
        temp=temp->next;
    }
    cout<<"NULL\n";
}

// Main function
int main() {
    // Creating list manually
    insertAtBeginning(12);
    insertAtBeginning(60);
    insertAtBeginning(45);
    insertAtBeginning(1);

    displayList();

    cout<<"\nInsert 100 at beginning:\n";
    insertAtBeginning(100);
    displayList();

    cout<<"\nInsert 200 after 45:\n";
    insertAfterValue(45, 200);
    displayList();

    cout<<"\nDelete at beginning:\n";
    deleteAtBeginning();
    displayList();

    cout<<"\nDelete node after 45:\n";
    deleteAfterValue(45);
    displayList();

    return 0;
}