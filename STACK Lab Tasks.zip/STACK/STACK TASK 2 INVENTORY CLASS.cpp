#include <iostream>
using namespace std;

// ================== Inventory Class ==================
class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;
public:
    Inventory() : serialNum(0), manufactYear(0), lotNum(0) {}

    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    void display() const {
        cout << "Serial Number: " << serialNum
             << ", Manufacturing Year: " << manufactYear
             << ", Lot Number: " << lotNum << endl;
    }
};

// ================== Node Structure ==================
struct Node {
    Inventory data;
    Node* next;
};

// ================== Stack Class ==================
class Stack {
private:
    Node* top;

public:
    Stack() : top(nullptr) {}

    // Push an inventory object onto the stack
    void push(const Inventory& item) {
        Node* newNode = new Node;
        newNode->data = item;
        newNode->next = top;
        top = newNode;
        cout << "Item pushed onto the stack.\n";
    }

    // Pop the top item from the stack
    bool pop() {
        if (isEmpty()) {
            cout << "Stack Underflow — no items to remove.\n";
            return false;
        } else {
            Node* temp = top;
            cout << "Popping item from stack:\n";
            top->data.display();
            top = top->next;
            delete temp;
            return true;
        }
    }

    // Check if stack is empty
    bool isEmpty() const {
        return (top == nullptr);
    }

    // Display all items in stack
    void displayAll() const {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "\nItems remaining in inventory:\n";
        Node* current = top;
        while (current != nullptr) {
            current->data.display();
            current = current->next;
        }
    }

    // Destructor to clean up memory
    ~Stack() {
        while (!isEmpty()) {
            pop();
        }
    }
};

// ================== Main Function ==================
int main() {
    Stack inventoryStack;
    int choice;

    cout << "=== Inventory Management System ===\n";

    do {
        cout << "\n1. Add part to inventory (Push)"
             << "\n2. Take part from inventory (Pop)"
             << "\n3. Display remaining inventory"
             << "\n4. Exit"
             << "\nEnter your choice: ";
        cin >> choice;

        if (choice == 1) {
            Inventory item;
            int serial, year, lot;

            cout << "Enter Serial Number: ";
            cin >> serial;
            cout << "Enter Manufacturing Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;

            item.setData(serial, year, lot);
            inventoryStack.push(item);
        }
        else if (choice == 2) {
            inventoryStack.pop();
        }
        else if (choice == 3) {
            inventoryStack.displayAll();
        }
        else if (choice == 4) {
            cout << "\nExiting program...\n";
            break;
        }
        else {
            cout << "Invalid choice! Try again.\n";
        }

    } while (choice != 4);

    cout << "\nFinal Inventory:\n";
    inventoryStack.displayAll();

    return 0;
}